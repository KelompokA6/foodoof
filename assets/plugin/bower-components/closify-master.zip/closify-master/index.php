<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script language="javascript" type="text/javascript" src="js/jquery-1.11.1.min.js" ></script>
	<script language="javascript" type="text/javascript" src="js/jquery-ui.min.js" ></script>
	<script language="javascript" type="text/javascript" src="js/closify-min.js" ></script>
	<script language="javascript" type="text/javascript" src="js/custom.js" ></script>
</head>
<body>
	<center>
		<div id="mas" class="closify" height="200" width="300"></div>
		<div id="abdu" class="closify" height="200" width="200"></div>
	</center>
</body>
</html>